/// <reference types="./phaser" />
/// <reference types="./SpinePlugin" />
/// <reference types="./SpineFile" />
/// <reference types="./SpineGameObject" />
/// <reference types="./SpineContainer" />
